#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include <omp.h>

double dot(double *A,double *B, int n);

int main(int argc, char **argv) {

  int n, nthreads, tid;
  int i,j;
  double z;
  if (argc!=3){
    printf("Wrong number of arguments!!! \n");
    printf("usage: %s  n NSamples\n",argv[0]);
    return -1;
  }
  n=atoi(argv[1]);
  int nSamples=atoi(argv[2]);
#pragma omp parallel
#pragma omp master
  nthreads = omp_get_num_threads();
  printf("Running '");
  for(i=0;i<argc;++i){
    printf("%s ",argv[i]);
  }
  printf("' for %d threads\n", nthreads);
  double *times = (double *) malloc(nthreads*sizeof(double));
  int *niter = (int *) malloc(nthreads*sizeof(int));
  double tmin=DBL_MAX;double tmax=0.0;
#pragma omp parallel shared(times,niter,tmin,tmax,z), private(tid)
{
  double stime;
  tid = omp_get_thread_num();
  double *A = (double *) malloc(n*sizeof(double));
  double *B = (double *) malloc(n*sizeof(double));
  niter[tid] = 0; 
  times[tid] = 0.0;
#pragma omp for private(i,j,stime) lastprivate(z) schedule(runtime)
  for (i=1; i<=nSamples; ++i) {
    for (j=0;j<n;++j){
      A[j] = (double) i * (double)j/(double) n;
      B[j] = (double) i * ((double)j+0.5)/(double) n;
    }
    stime = omp_get_wtime();
    z=dot(A,B,n);
    times[tid] = times[tid] + (omp_get_wtime()-stime);
    niter[tid]++;
  }
  free(A); 
  free(B);
}
  double timeAvg = 0.0;
  for(i=0;i<nthreads;++i){
    if (tmin>times[i]) tmin=times[i];
    if (tmax<times[i]) tmax=times[i];
    timeAvg+=times[i];
  }
  timeAvg/=nthreads;
  double sig=0.0;
  for(i=0;i<nthreads;++i){      
    sig+=(times[i]-timeAvg)*(times[i]-timeAvg);
  }
  sig=sqrt(sig/nthreads);

  printf("#Thread  |       Size|        Time (s)|    Number|\n");
  for(i=0;i<nthreads;++i){
    printf("%6d %12d %16.8f %12d\n",i+1,n,times[i],niter[i]);
  }
  printf("\nLast inner product: %16.8E\n",z);
  printf("\nSummary:\n");
  printf("#Size  n    |  Avg. Time (s) |   Min. Time(s) |   Max. Time(s) | σ Time(s)\n");
  printf("%12d %16.8f %16.8f %16.8f %16.8f\n",n,timeAvg,tmin,tmax,sig);

  free(times);
  free(niter);
  return 0;
}

double dot(double *A,double *B, int n){
  int i;
  double s;

//#pragma omp parallel num_threads(2)
//#pragma omp for reduction (+:s)
  for(i=0;i<n;++i){
    s+=A[i]*B[i];
  }
//Using critical directive
//#pragma omp for 
//  for(i=0;i<n;++i){
//  #pragma omp critical
//    s+=A[i]*B[i];
//  }

  return s;
}
