#include<stdio.h>
#include<stdlib.h>
#include<omp.h>
#include<time.h>

int main(void){
    int i, j, n, tid, astart, nthreads, *a;

/* Enter the array size */
    printf("Please enter the size of the array\n");
    scanf("%d",&n);
    if (n<2 || n>1000) {
      printf(" Enter a positive number bigger than 2 and less than 10001\n");
      exit(1);
    }


    astart = 0;


/* Start of parallel region */
#pragma omp parallel private(i,j,tid,a), shared(nthreads,n,astart)
{
      tid=omp_get_thread_num();
      nthreads=omp_get_num_threads();

      a = (int *) malloc(n*sizeof(int));
      if (a == NULL) {
        printf(" Cannot allocate array for id %d, stopping\n",tid);
        exit(2);
      }

#pragma omp for ordered
      for (i=0; i<nthreads; i++) {
#pragma omp ordered
{
        srand(time(NULL)*tid);
        astart = astart + rand()%11;
}


        for (j=0; j<n; j++) a[j] = astart;

} /* end for loop */

      printf("Hello from thread %d out of %d my a is: %d\n", tid,nthreads,a[0]);

      free(a);
      a = NULL;
} /* end parallel region */


   if (a == NULL) a = (int *) malloc(n*sizeof(int));
   if (a == NULL) {
      printf(" Cannot allocate array for master, stopping\n");
      exit(3);
    }
    for (i=0; i<n; i++) a[i] = astart;

    printf("Hello from the master thread my a is: %d\n",a[0]);  

    return 0;
}

