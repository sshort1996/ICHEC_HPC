#include<stdio.h>
#include<omp.h>

void main(){
  int tid, nthreads;
#pragma omp parallel private(tid),shared(nthreads)
{
  tid=omp_get_thread_num();
  nthreads=omp_get_num_threads();
  printf("Hello from thread %d\n", tid);
  if(tid==0)
    printf("Total number of threads: %d\n", nthreads);
//Alternatively
//#pragma omp master
  //printf("Total number of threads: %d\n", nthreads);
}
}

