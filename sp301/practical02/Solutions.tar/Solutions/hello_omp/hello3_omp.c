#include<stdio.h>
#include<omp.h>

int main(){
  int tid, nthreads;
#pragma omp parallel private(tid), shared(nthreads)
{	
  tid=omp_get_thread_num();
  nthreads=omp_get_num_threads();
  if(tid==0)	
    printf("Total number of threads: %d\n", nthreads);
}
omp_set_num_threads(6); 
#pragma omp parallel private(tid), shared(nthreads)
{	
  tid=omp_get_thread_num();
  nthreads=omp_get_num_threads();
  if(tid==0)	
    printf("Total number of threads: %d\n", nthreads);
}
#pragma omp parallel private(tid), shared(nthreads), num_threads(8)
{	
  tid=omp_get_thread_num();
  nthreads=omp_get_num_threads();
  if(tid==0)	
    printf("Total number of threads: %d\n", nthreads);
}
}
