#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include <omp.h>

void vecadd(double *A,double *B, double *s, int n);

int main(int argc, char **argv) {

  int n, nthreads,tid;
  int i,j;
  if (argc!=3){
    printf("Wrong number of arguments!!! \n");
    printf("usage: %s  n NSamples\n",argv[0]);
    return -1;
  }
  n=atoi(argv[1]);
  int nSamples=atoi(argv[2]);//Compute addition multiple times
#pragma omp parallel 
#pragma omp master
  nthreads = omp_get_num_threads();
  printf("Running '");
  for(i=0;i<argc;++i){
    printf("%s ",argv[i]);
  }
  printf("' for %d threads\n", nthreads);
  double *times = (double *) malloc(nthreads*sizeof(double));//stats over thread
  int *niter = (int *) malloc(nthreads*sizeof(int));
  double tmin=DBL_MAX;double tmax=0.0;
#pragma omp parallel shared(times,niter,tmin,tmax), private(tid) 
{
  double stime;
  tid = omp_get_thread_num();    
  double *A = (double *) malloc(n*sizeof(double));
  double *B = (double *) malloc(n*sizeof(double));
  double *C = (double *) malloc(n*sizeof(double));
  times[tid] = 0.0;
  niter[tid] = 0;
#pragma omp for private(i,j,stime) schedule(guided, 1)
  for (i=1; i<=nSamples; ++i) {
    for (j=0;j<n;++j){
      A[j] = (double) i * (double)j/(double) n;
      B[j] = (double) i * ((double)j+0.5)/(double) n;
    }
    stime = omp_get_wtime();
    vecadd(A,B,C,n);
    times[tid] += omp_get_wtime()-stime;
    niter[tid]++;
    }
  free(A); 
  free(B); 
  free(C);
}
  double timeAvg = 0.0;
  for(i=0;i<nthreads;++i){
    if (tmin>times[i]) tmin=times[i];
    if (tmax<times[i]) tmax=times[i];
    timeAvg+=times[i];
  }
  timeAvg/=nthreads;
  double sig=0.0;
  for(i=0;i<nthreads;++i){      
    sig+=(times[i]-timeAvg)*(times[i]-timeAvg);
  }
  sig=sqrt(sig/nthreads);

  printf("#Thread  |       Size|        Time (s)|   Number|\n");
  for(i=0;i<nthreads;++i){
    printf("%6d %12d %16.8f %12d\n",i,n,times[i],niter[i]);
  }
  printf("\nSummary:\n");
  printf("#Size  n    |  Avg. Time (s) |   Min. Time(s) |   Max. Time(s) | σ Time(s)\n");
  printf("%12d %16.8f %16.8f %16.8f %16.8f\n",n,timeAvg,tmin,tmax,sig);

  free(times); 
  free(niter);

  return 0;
}

void vecadd(double *A, double *B, double *s, int n){
  int i;

  for(i=0;i<n;++i){
    s[i]=A[i]+B[i];
  }
}
